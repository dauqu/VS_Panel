import React from "react";
import { FaPlayCircle } from "react-icons/fa";
import { GoThreeBars } from "react-icons/go";
import "../assets/css/Header.css"
function Header() {
  return (
    <>
    <div className="mainheader bg-[#165461] p-2  ">
      {/* top part-----------start form here------------------ */}
      <div className="flex justify-around p-6 items-center ">
        <div className="text-[#F6F9F9] text-[30px] text-center font-semibold w-[100px]">
          saasta
        </div>
        <div className=" items-center justify-center text-white text-[15px] w-full  hidden md:flex">
          <div className="m-2 text-center cursor-pointer">Home+</div>
          <div className="m-2 text-center cursor-pointer">Features</div>
          <div className="m-2 text-center cursor-pointer">Service</div>
          <div className="m-2 text-center cursor-pointer">Pricing</div>
          <div className="m-2 text-center cursor-pointer">Contact</div>
        </div>
        <div className="min-w-[120px] hidden md:block">
          <button className="bg-[#337681] p-2 text-[#DCE8E9] text-[14px] text-center font-semibold">
            Get The App
          </button>
        </div>
        
        <div className="" onClick={function() {
            if (document.getElementsByClassName("menubar")[0].style.left == "0px") {
              document.getElementsByClassName("menubar")[0].style.left = "-100%";
              document.getElementsByClassName("menubar")[0].style.transition = "0.5s";
            } else {
              document.getElementsByClassName("menubar")[0].style.left = "0px";
              document.getElementsByClassName("menubar")[0].style.transition = "0.5s";
            }
          }}>
          <button className="block md:hidden"><GoThreeBars style={{color:"white"}}/></button>
        </div>
      </div>
      {/* top part-----------ends here------------------ */}

      {/* middle part-----------start form here------------------ */}

      <div className="text-center items-center xl:p-16 mb-[180px]">
        <div className="text-white font-bold text-[45px]">
          Discover With New Dashboard
        </div>
        <div className="  text-[#B1CBCF] text-[17px] sm:w-1/2 m-auto text-center">
          Lorem ipsum dolor sit, amet consectetur adipisicing elit. Labore, qui
          delectus ad facilis sunt repudiandae quod quas dolorum accusantium
          dignissimos id, corrupti possimus impedit consequuntur eveniet sint
          deleniti! Doloremque, earum.
        </div>
        <div className="flex mt-8 justify-center">
          <div className="">
            <button className="bg-[#FFFFFF] p-2 text-[#3E6F7A] font-semibold">
              Get Started
            </button>
          </div>
          <div className="w-[20px]"></div>
          <div className="flex items-center cursor-pointer">
            <div>
              <FaPlayCircle
                style={{
                  color: "white",
                  fontSize: "38px",
                  border: "3px solid #71A1A8",
                  borderRadius: "50%",
                }}
              />
            </div>
            <div className="text-[#D3E2E4] ml-2 text-[18px]"> Play Demo</div>
          </div>
        </div>
      </div>

      {/* middle part-----------ends here------------------ */}
    </div>
    <div className="menubar fixed  left-[-100%] top-[80px] h-[100vh] bg-[white] p-4 z-10 w-full">
          <div className="cursor-pointer text-[20px] font-semibold mt-4">Home </div>
          <div className="cursor-pointer text-[20px] font-semibold mt-4">Feature</div>
          <div className="cursor-pointer text-[20px] font-semibold mt-4">Service</div>
          <div className="cursor-pointer text-[20px] font-semibold mt-4">Pricing</div>
          <div className="cursor-pointer text-[20px] font-semibold mt-4">Contact</div>
    </div>
    </>
  );
}

export default Header;
